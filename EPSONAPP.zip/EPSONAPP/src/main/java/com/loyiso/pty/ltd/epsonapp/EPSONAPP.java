/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.loyiso.pty.ltd.epsonapp;

/**
 *
 * @author RC_Student_lab
 */
public class EPSONAPP {

    public static void main(String[] args) {
        System.out.println("REGISTRATION.java");
    }
}
