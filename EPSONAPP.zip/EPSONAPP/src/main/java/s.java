

class s {
}
