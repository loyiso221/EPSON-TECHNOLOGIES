

class db {

    static Object mycon() {
        return (null);
    }
}
