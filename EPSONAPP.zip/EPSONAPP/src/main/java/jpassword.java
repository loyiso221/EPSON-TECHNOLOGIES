

class jpassword {
}
