

class jtuser {
}
