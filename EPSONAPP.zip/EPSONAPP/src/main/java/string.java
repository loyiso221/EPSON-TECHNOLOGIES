

class string {
}
