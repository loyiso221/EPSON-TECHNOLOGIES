package login;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class db {
    public static Connection mycon(){
        Connection con = null;
        try {
            // Correcting the class name to match the actual MySQL JDBC driver class
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Fixing the getConnection method parameters, including adding a username and password
            con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/epsonapp", "root", "");
        } catch (ClassNotFoundException | SQLException e) {
            // Correcting syntax error with "System.out.println" and printing the error
            System.out.println(e);
        }
        return con;
    }
}
